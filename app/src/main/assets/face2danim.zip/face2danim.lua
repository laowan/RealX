local Config = require("config")
local FaceLandmark = require("FaceLandmark")

TAG = "OF-Face2dAnim"

local vs = [[
    attribute vec2 aPosition;
    attribute vec2 aTextureCoord;
    varying vec2 vTexCoord;
    void main() 
    {
	    gl_Position = vec4(aPosition, 0.0, 1.0);
		vTexCoord = aTextureCoord;
    }
]]

local fs = [[
    precision highp float;
    uniform sampler2D uTexture;
    varying vec2 vTexCoord;
    void main()
    {
        gl_FragColor = texture2D(uTexture, vTexCoord);
        //gl_FragColor = vec4(1, 1, 1, 1);
    }
]]

local FloatPerVertex = 4
local FacePointCount = 106
local ExtPointCount = 8

local _renderPass = nil
local _faceVbo = nil
local _faceIbo = nil
local _faceVertexBuffer = nil
local _faceTexture = nil

function table_contain(t, value)
    for k, v in ipairs(t) do
        if v == value then
            return true
        end
    end
    return false
end

function table_copy(t)
    local newTable = {}
    for k, v in pairs(t) do
        newTable[k] = v
    end 
    return newTable
end

function calcBoundingBox(ignoreIndices)
    local minx, maxx = 1.0, 0.0
    local miny, maxy = 1.0, 0.0
    local shapeList = { Config.BaseShape }
    for i = 1, #Config.ExperShapes do
         table.insert(shapeList, Config.ExperShapes[i].shape)
    end
    print("calcBoundingBox " .. tostring(#shapeList))

    for i = 1, #shapeList do
        local shape = shapeList[i]
        for j = 1, #shape / 2 do
            if not table_contain(ignoreIndices, j-1) then
                local x = shape[2 * (j - 1) + 1]
                local y = shape[2 * (j - 1) + 2]
                if minx > x then minx = x end
                if maxx < x then maxx = x end
                if miny > y then miny = y end
                if maxy < y then maxy = y end
            end
        end
    end
    return minx, maxx, miny, maxy
end

function calcShapeBoundingBox(ignoreIndices, shape)
    local minx, maxx = 1.0, 0.0
    local miny, maxy = 1.0, 0.0
    for j = 1, #shape / 2 do
        if not table_contain(ignoreIndices, j - 1) then
            local x = shape[2 * (j - 1) + 1]
            local y = shape[2 * (j - 1) + 2]
            if x > 0.0 and y > 0.0 then
                if minx > x then minx = x end
                if maxx < x then maxx = x end
                if miny > y then miny = y end
                if maxy < y then maxy = y end
            end
        end
    end
    return minx, maxx, miny, maxy
end

function getBlendshape(baseShape, expr, minx, maxx, miny, maxy)
    local bs = {}
    local shape = expr.shape
    for i = 1, #baseShape / 2 do
        if table_contain(expr.indices, i - 1) then
            local x_base = (baseShape[2 * (i - 1) + 1] - minx) / (maxx - minx)
            local y_base = (baseShape[2 * (i - 1) + 2] - miny) / (maxy - miny)
            local x = (shape[2 * (i - 1) + 1] - minx) / (maxx - minx)
            local y = (shape[2 * (i - 1) + 2] - miny) / (maxy - miny)
            table.insert(bs, x - x_base)
            table.insert(bs, y - y_base)
        else
            table.insert(bs, 0)
            table.insert(bs, 0)
        end
    end
    return bs
end

function generateNewShape(baseShape, weights)
    --local minx, maxx, miny, maxy = calcBoundingBox(Config.IgnoeIdices)
    --print(minx, maxx, miny, maxy)
    --local bs = getBlendshape(Config.BaseShape, Config.MouthOpenShape, minx, maxx, miny, maxy)
    --print(bs[93 * 2 + 1], bs[93 * 2 + 2])

    local minx, maxx, miny, maxy = calcShapeBoundingBox(Config.IgnoeIdices, baseShape)

    local bs = Config.ExperShapes[1].delta
    print(bs[93 * 2 + 1], bs[93 * 2 + 2])

    local newShape = {}
    for i = 1, #baseShape / 2 do
        local x = (baseShape[2 * (i - 1) + 1] - minx) / (maxx - minx)
        local y = (baseShape[2 * (i - 1) + 2] - miny) / (maxy - miny)
        for j = 1, #Config.ExperShapes do
            local bs = Config.ExperShapes[j].delta
            x = x + weights[j] * bs[2 * (i - 1) + 1]
            y = y + weights[j] * bs[2 * (i - 1) + 2]
        end
        --x = x + weights[1] * bs[2 * (i - 1) + 1]
        --y = y + weights[1] * bs[2 * (i - 1) + 2]
        x = x * (maxx - minx) + minx
        y = y * (maxy - miny) + miny
        table.insert(newShape, x)
        table.insert(newShape, y)
    end
    return newShape
end

function fillVertexBuffer(vertexBuffer, vertices, uvs)
    for i = 1, FacePointCount do
    	if vertices then
        	vertexBuffer:set((i - 1) * FloatPerVertex + 0, 2 * vertices[i*2-1] - 1)
        	vertexBuffer:set((i - 1) * FloatPerVertex + 1, 2 * vertices[i*2] - 1)
        end

        if uvs and uvs[i*2] then
            vertexBuffer:set((i - 1) * FloatPerVertex + 2, uvs[i*2-1])
            vertexBuffer:set((i - 1) * FloatPerVertex + 3, uvs[i*2])
        end
    end

    for i = 1, ExtPointCount do
        vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 0, 2 * Config.FaceExtPoint[2 * (i - 1 ) + 1] - 1)
        vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 1, 2 * Config.FaceExtPoint[2 * (i - 1 ) + 2] - 1)
        vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 2, Config.FaceExtPoint[2 * (i - 1 ) + 1])
        vertexBuffer:set(FacePointCount * FloatPerVertex + (i - 1) * FloatPerVertex + 3, Config.FaceExtPoint[2 * (i - 1 ) + 2])
    end
end

function midPoint(landmarks, id1, id2)
    local x = (landmarks[id1 * 2 + 1] + landmarks[id2 * 2 + 1]) / 2.0
    local y = (landmarks[id1 * 2 + 2] + landmarks[id2 * 2 + 2]) / 2.0
    return x, y
end

function fillLandmark(landmarks, data)
    for i = 1, #Config.ValidIndices do
        local idx = Config.ValidIndices[i]
        landmarks[idx * 2 + 1] = data[2 * (i - 1) + 1] / 255
        landmarks[idx * 2 + 2] = data[2 * (i - 1) + 2] / 255
    end
    landmarks[98 * 2 + 1], landmarks[98 * 2 + 2] = midPoint(landmarks, 84, 90)
    landmarks[102 * 2 + 1], landmarks[102 * 2 + 2] = midPoint(landmarks, 84, 90)
end

function fillExtPoint(landmarks)
    local minx, maxx, miny, maxy = calcShapeBoundingBox(Config.IgnoeIdices, landmarks)
    print("fillExtPoint")
    print(minx, maxx, miny, maxy)
    local dx = (maxx - minx) / 10
    local dy = (maxy - miny) / 5
    Config.FaceExtPoint[2 * 0 + 1], Config.FaceExtPoint[2 * 0 + 2] = minx - dx, miny - dy -- 106
    Config.FaceExtPoint[2 * 1 + 1], Config.FaceExtPoint[2 * 1 + 2] = minx - dx, maxy + dy -- 107
    Config.FaceExtPoint[2 * 2 + 1], Config.FaceExtPoint[2 * 2 + 2] = maxx + dx, maxy + dy -- 108
    Config.FaceExtPoint[2 * 3 + 1], Config.FaceExtPoint[2 * 3 + 2] = maxx + dx, miny - dy -- 109
end

function initParams(context, filter)
    OF_LOGI(TAG, "call initParams")
    filter:insertResParam("TargetPhoto", OF_ResType_Image, "target.png")
    filter:insertBoolParam("Avatar", true)
    filter:insertFloatParam("OpenMouth", 0.0, 1.0, 0.0)
    filter:insertFloatParam("CloseLeftEye", 0.0, 1.0, 0.0)
    filter:insertFloatParam("CloseRightEye", 0.0, 1.0, 0.0)
    return OF_Result_Success
end

function initRenderer(context, filter)
    OF_LOGI(TAG, "call initRenderer")

    local pngPath = filter:resFullPath(filter:resParam("TargetPhoto"))
    _faceTexture = context:loadTexture(pngPath)
    print(pngPath)

    _renderPass = context:createCustomShaderPass(vs, fs)
    
    FaceLandmark:init(context)

    local minx, maxx, miny, maxy = calcBoundingBox(Config.IgnoeIdices)
    print(minx, maxx, miny, maxy)

    for i = 1, #Config.ExperShapes do
        Config.ExperShapes[i].delta = getBlendshape(Config.BaseShape, Config.ExperShapes[i], minx, maxx, miny, maxy)
    end

    return OF_Result_Success
end

function teardownRenderer(context, filter)
    OF_LOGI(TAG, "call teardownRenderer")
    context:destroyCustomShaderPass(_renderPass)
    if _faceVbo then
	    context:destroyBuffer(_faceVbo)
	    context:destroyBuffer(_faceIbo)
	end
    _faceVbo = nil
    _faceIbo = nil
    _faceVertexBuffer = nil

    context:destroyTexture(_faceTexture)

    FaceLandmark:teardown()
    return OF_Result_Success
end

function applyRGBA(context, filter, frameData, inTex, outTex, debugTex)
    local frequencyData = frameData.audioFrameData.frequencyData
    if frequencyData[1] > 0 and _faceVbo == nil then
        print("init vbo and ibo")
        fillLandmark(Config.Landmark106, frequencyData)
        fillExtPoint(Config.Landmark106)
    
        _faceVertexBuffer = FloatArray.new(4 * (FacePointCount + ExtPointCount))
        fillVertexBuffer(_faceVertexBuffer, Config.Landmark106, Config.Landmark106)
        _faceVbo = context:createVertexBuffer(_faceVertexBuffer, DYNAMIC_DRAW)
    
        local indexCount = #Config.FaceIndices
        local indexBuffer = Uint16Array.new(indexCount)
        for i = 1, indexCount do
            indexBuffer:set(i - 1, Config.FaceIndices[i])
        end
        _faceIbo = context:createIndexBuffer(indexBuffer, STATIC_DRAW)
    end

    if _faceVbo then
        local openMouthWeight = 0.0
        local closeLeftEyeWeight = 0.0
        local closeRightEyeWeight = 0.0
        if not filter:boolParam("Avatar") then
            openMouthWeight = filter:floatParam("OpenMouth")
            closeLeftEyeWeight = filter:floatParam("CloseLeftEye")
            closeRightEyeWeight = filter:floatParam("CloseRightEye")
        else
            local faceData = frameData.faceFrameDataArr.faceItemArr[1]
            openMouthWeight = faceData.blendshapeWeightMap[25]
            closeLeftEyeWeight = faceData.blendshapeWeightMap[10]
            closeRightEyeWeight = faceData.blendshapeWeightMap[9]
        end

        local weights = { openMouthWeight, closeLeftEyeWeight, closeRightEyeWeight }
        local landmark106 = generateNewShape(Config.Landmark106, weights)

        fillVertexBuffer(_faceVertexBuffer, landmark106, nil)
        _faceVbo:updateFloatArrayOffset(0, _faceVertexBuffer, 0, (FacePointCount + ExtPointCount) * FloatPerVertex)

        -- render
        context:copyTexture(inTex, outTex)
        context:setViewport(0, 0, outTex.width, outTex.height)
            
        context:bindFBO(outTex)
        context:setClearColor(0, 0, 0, 1)
        context:clearColorBuffer()

        context:setBlend(false)
        context:setCullFace(RS_CullMode_None)
        context:setDepthMask(false)
        context:setDepthTest(false)
        context:setDepthFunc(RS_DepthFunc_LESS_EQUAL)
        
        _renderPass:use()
        _renderPass:setUniformTexture("uTexture", 0, _faceTexture:toOFTexture().textureID, TEXTURE_2D)
        
        -- draw face mesh
        _faceVbo:bind()
        local stride = FloatPerVertex * 4
        _renderPass:setVertexAttrib("aPosition", 2, FLOAT, 0, stride, 0)
        _renderPass:setVertexAttrib("aTextureCoord", 2, FLOAT, 0, stride, 2 * 4)
        _faceIbo:bind()
        _renderPass:drawElements(TRIANGLES,  #Config.FaceIndices, UNSIGNED_SHORT, 0)
    else
        context:copyTexture(inTex, outTex)
    end

    if debugTex then
        if frameData.faceFrameDataArr.faceCount > 0 then
            local faceData = frameData.faceFrameDataArr.faceItemArr[1]
            FaceLandmark:draw(faceData, frameData.timestamp, debugTex)
        end
    end
    return OF_Result_Success
end

function requiredFrameData(context, game)
    return { OF_RequiredFrameData_FaceLandmarker, OF_RequiredFrameData_HeadPoseEstimate, OF_RequiredFrameData_Avatar, OF_RequiredFrameData_AudioBeat }
end

function onApplyParams(context, filter)
    OF_LOGI(TAG, "call onApplyParams")
    local pngName = filter:resParam("TargetPhoto")
    print(pngName)
    return OF_Result_Success
end

function readObject(context, filter, archiveIn)
    OF_LOGI(TAG, "call readObject")
    return OF_Result_Success
end

function writeObject(context, filter, archiveOut)
    OF_LOGI(TAG, "call writeObject")
    return OF_Result_Success
end
