FaceLandmark = {

}

local _context = nil
local point_render = nil
local point_program = nil
local point_array = nil
local point_color_array = nil
local point_array_count = 106-- 68
local avatar_point_render = nil
local avatar_point_array = nil
local avatar_point_color_array = nil
local silhouette_render = nil
local silhouette_program = nil
local silhouette_array = nil
local Pt68To106 = {
    0, 2, 4, 6, 8, 10, 12, 14, 16, 18,
    20, 22, 24, 26, 28, 30, 32, 33, 34, 35,
    36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 53, 54, 55,
    56, 57, 58, 59, 60, 61, 62, 63, 84, 85,
    86, 87, 88, 89, 90, 91, 92, 93, 94, 95,
    96, 97, 98, 99, 100, 101, 102, 103, 68, 69,
    70, 71, 72 }
    
local FaceVertexIdx = {
    4644,552,5753,2714,5749,2561,4044,5017,4045,5020,
    1268,2509,2169,4543,4563,161,5346,3131,4586,877,
    5558,581,600,2669,593,605,4150,1316,4125,1322,
    4141,1309,25,33,224,3334,3377,749,2925,3011,
    2974,726,27,5181,18,719,3004,3037,3018,5210,
    5154,659,2893,5512,338,251,2100,315,1031,3359,
    3433,3603,4762,3971,1375,2906,5230,3023}

function FaceLandmark:initPoints(context)
	_context = context
    
	local VS = [[
        attribute vec4 aPosition;
        attribute vec4 aColor;
        varying vec4 vColor;
        void main()
        {
            gl_PointSize = 3.0;
            gl_Position = aPosition;
            vColor = aColor;
        }
        ]]

    local FS = [[
        precision mediump float;
        varying vec4 vColor;
        void main()
        {
            gl_FragColor = vColor;
        }
    ]]
    if point_program == nil then
        point_program = context:createCustomShaderPass(VS, FS)
    end
    
    if point_render == nil then
        local pointCount = point_array_count
        point_array = FloatArray.new(pointCount * 2)
        point_color_array = FloatArray.new(pointCount * 4)
        
        for i = 1, pointCount do
            point_array:set((i - 1) * 2, 0.0)
            point_array:set((i - 1) * 2 + 1, 0.0)

            -- point color
            point_color_array:set((i - 1) * 4 + 0, 0)
            point_color_array:set((i - 1) * 4 + 1, 1)
            point_color_array:set((i - 1) * 4 + 2, 0)
            point_color_array:set((i - 1) * 4 + 3, 1)
        end
        
        point_render = PointSprite2DRender.new(point_array, pointCount)
        point_render:updateColors(point_color_array, pointCount)
    end
    
    if avatar_point_render == nil then
        local pointCount = 50
        avatar_point_array = FloatArray.new(pointCount * 2)
        avatar_point_color_array = FloatArray.new(pointCount * 4)
        for i = 1, pointCount do
            avatar_point_array:set((i - 1) * 2, 0.0)
            avatar_point_array:set((i - 1) * 2 + 1, 0.0)
            
            -- point color
            avatar_point_color_array:set((i - 1) * 4 + 0, 1)
            avatar_point_color_array:set((i - 1) * 4 + 1, 0)
            avatar_point_color_array:set((i - 1) * 4 + 2, 0)
            avatar_point_color_array:set((i - 1) * 4 + 3, 1)
        end
        
        avatar_point_render = PointSprite2DRender.new(avatar_point_array, pointCount)
        avatar_point_render:updateColors(avatar_point_color_array, pointCount)
    end
end

function FaceLandmark:teardownPoints()
	point_render = nil
    point_array = nil
    point_color_array = nil
    
    avatar_point_render = nil
    avatar_point_array = nil
    avatar_point_color_array = nil
    
    _context:destroyCustomShaderPass(point_program)
    point_program = nil
end

function FaceLandmark:updatePoints(context, pnts, pointCount)
    pointCount = point_array_count
    for i = 1, pointCount do
        local idx = i --Pt68To106[i] + 1
        point_array:set((i - 1) * 2, pnts[2*(idx-1)+1] * 2 - 1)
        point_array:set((i - 1) * 2 + 1, pnts[2*(idx-1)+2] * 2 - 1)
        
        -- point color
        point_color_array:set((i - 1) * 4 + 0, 0)
        point_color_array:set((i - 1) * 4 + 1, 1)
        point_color_array:set((i - 1) * 4 + 2, 0)
        point_color_array:set((i - 1) * 4 + 3, 1)
    end
    point_render:updatePoints(point_array, pointCount)
    point_render:updateColors(point_color_array, pointCount)
end

function FaceLandmark:updateAvatarPoints(context, pnts, pmat, mvmat)
    local pointCount = 50
    for i = 1, pointCount do
        local modelPnt = Vec4f.new(pnts[FaceVertexIdx[i] * 9 + 1], pnts[FaceVertexIdx[i] * 9 + 2], pnts[FaceVertexIdx[i] * 9 + 3], 1.0)
        local screenPnt = pmat * mvmat * modelPnt
        avatar_point_array:set((i - 1) * 2, screenPnt.x / screenPnt.w)
        avatar_point_array:set((i - 1) * 2 + 1, screenPnt.y / screenPnt.w) 
    end
    avatar_point_render:updatePoints(avatar_point_array, pointCount)
end

function FaceLandmark:initSilhouette(context)
    local VS = [[
        attribute vec4 aPosition;
        void main()
        {
            gl_PointSize = 3.0;
            gl_Position = aPosition;
        }
        ]]

    local FS = [[
        precision mediump float;
        void main()
        {
            gl_FragColor = vec4(1.0, 1.0, 0.0, 1.0);
        }
    ]]
    if silhouette_program == nil then
        silhouette_program = context:createCustomShaderPass(VS, FS)
    end
    
    if silhouette_render == nil then
        local pointCount = 17 - 1
        silhouette_array = FloatArray.new(pointCount * 2 * 2)
        for i = 1, pointCount do
            silhouette_array:set((i - 1) * 4, 0.0)
            silhouette_array:set((i - 1) * 4 + 1, 0.0)
            silhouette_array:set((i - 1) * 4 + 2, 0.0)
            silhouette_array:set((i - 1) * 4 + 3, 0.0)
        end
        silhouette_render = Line2DRender.new(silhouette_array, pointCount * 2)
    end
end

function FaceLandmark:teardownSilhouette()
    silhouette_render = nil
    silhouette_array = nil
    _context:destroyCustomShaderPass(silhouette_program)
    silhouette_program = nil
end

function FaceLandmark:updateSilhouette(context, pnts, pmat, mvmat)
    local vcnt = 5868
    local pntArray = FloatArray.new(17 * 2)
    for i = 1, 17 do
        local modelPnt = Vec4f.new(pnts[vcnt * 9 + (i - 1) * 3 + 1], pnts[vcnt * 9 + (i - 1) * 3 + 2], pnts[vcnt * 9 + (i - 1) * 3 + 3], 1.0)
        local screenPnt = pmat * mvmat * modelPnt
        pntArray:set((i - 1) * 2, screenPnt.x / screenPnt.w)
        pntArray:set((i - 1) * 2 + 1, screenPnt.y / screenPnt.w) 
    end
    
    for i = 1, 16 do
        silhouette_array:set((i - 1) * 4,     pntArray:get((i - 1) * 2))
        silhouette_array:set((i - 1) * 4 + 1, pntArray:get((i - 1) * 2 + 1))
        silhouette_array:set((i - 1) * 4 + 2, pntArray:get((i) * 2))
        silhouette_array:set((i - 1) * 4 + 3, pntArray:get((i) * 2 + 1))
    end
    
    silhouette_render:updatePoints(silhouette_array, 16 * 2)
end

function FaceLandmark:init(context)
    FaceLandmark:initPoints(context)
    --FaceLandmark:initSilhouette(context)
end

function FaceLandmark:teardown()
    FaceLandmark:teardownPoints()
    --FaceLandmark:teardownSilhouette()
end

function FaceLandmark:draw(faceFrameData, frameTime, outTex)
    local faceData = faceFrameData
    FaceLandmark:updatePoints(_context, faceData.facePoints, faceData.facePointsCount)
    
    _context:bindFBO(outTex)
    _context:setBlend(true)
    _context:setBlendMode(RS_BlendFunc_SRC_ALPHA, RS_BlendFunc_INV_SRC_ALPHA)
    
    point_program:use()
    point_render:draw(point_program, false)
    
    --local modelMat = Matrix4f.new()
    --modelMat:set(faceData.faceMesh.modelViewMat)
    --
    --local projMat = Matrix4f.new()
    --projMat:set(faceData.faceMesh.projectionMat)
    --projMat = Matrix4f.ReflectMat() * projMat
    --
    --FaceLandmark:updateAvatarPoints(_context, faceData.faceMesh.vertices, projMat, modelMat)
    --avatar_point_render:draw(point_program, false)
    
    --FaceLandmark:updateSilhouette(_context, faceData.faceMesh.vertices, projMat, modelMat)
    --silhouette_program:use()
    --silhouette_render:draw(silhouette_program, false)
    
    _context:setBlend(false)
end

return FaceLandmark